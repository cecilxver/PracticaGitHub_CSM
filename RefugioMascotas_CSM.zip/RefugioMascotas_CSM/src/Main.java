import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Mascota Uno = new Mascota("Trompita", "Elefante", 4, 5, 10); //creamos las distintas mascotas
        Mascota Dos = new Mascota("Bola", "Perro", 11, 3, 1);
        Mascota Tres = new Mascota("John", "Cerdo", 2, 2, 4);
        Mascota[] arrayMascotas={Uno,Dos,Tres}; //este array se usa para la función comprobarEstado()

        int dia=0; //creamos el contador de días
        System.out.println("Bienvenido al Refugio Animalitos Felices");
        System.out.println();
        //mostramos el menú y se guarda en el valor opción
        System.out.println("Menú: \n1. Ver todas las mascotas" + "\n 2. Alimentar a una mascota " + "\n 3. Jugar con una mascota " + "\n 4. Hacer dormir a una mascota" + "\n 5. Celebrar cumpleaños de mascota " + "\n 6. Ver estado del refugio " + " \n 7. Salir");
        int opcion = sc.nextInt();
        boolean menu = false; //esto sirve para repetir el menú si es necesario
        while (opcion != 7) { //mientras la opción no sea la opción de salida, seguirá el bucle
            dia++; //cada vez que entra en el bucle, el día aumenta
            System.out.println("------------------------------------");
            System.out.println("Día "+dia+" en el refugio de Mascotas Felices!");
            System.out.println("------------------------------------");
            System.out.println();
            if(dia!=1){
            DificultadDia(arrayMascotas, dia); //llamamos a la función dificultad dia
            }
            if (menu) { //si el menu es true, debe mostrar de nuevo el menú
                System.out.println("Menú: \n1. Ver todas las mascotas" + "\n 2. Alimentar a una mascota " + "\n 3. Jugar con una mascota " + "\n 4. Hacer dormir a una mascota" + "\n 5. Celebrar cumpleaños de mascota " + "\n 6. Ver estado del refugio " + " \n 7. Salir");
                opcion = sc.nextInt();
                menu=false;
            }
            switch (opcion) {
                case 1:
                    verEstado(Uno,Dos,Tres); //llamamos al método_
                    menu = true;
                    break;
                case 2:
                    Alimentar(Uno, Dos, Tres); //llamamos al método_
                    ComprobarEstado(arrayMascotas);
                    menu = true; //hacemos que menu sea true para que se vuelva a mostrar
                    break;
                case 3:
                    Jugar(Uno, Dos, Tres);
                    ComprobarEstado(arrayMascotas);
                    menu = true;
                    break;
                case 4:
                    Dormir(Uno, Dos, Tres);
                    ComprobarEstado(arrayMascotas);
                    menu = true;
                    break;
                case 5:
                    Cumpleaños(Uno, Dos, Tres);
                    ComprobarEstado(arrayMascotas);
                    menu = true;
                    break;
                case 6:
                    EstadoRefugio(Uno,Dos,Tres,arrayMascotas);
                    menu = true;
                    break;
                case 7:
                    System.out.println("Saliendo del Refugio de Animalitos Felices. . ."); //mostramos un mensaje de despedida
            }


        }

    }
    /**
     * Aumenta la dificultad cada día.
     * @param arraymascota Array donde se encuentran todas las mascotas.
     */
    public static void DificultadDia (Mascota[]arraymascota,int dia){
        for (Mascota m : arraymascota) { //para automatizarlo, he usado un bucle for que recorra todas las mascotas y les suba el hambre, cada día les sube más
            m.setHambre(m.getHambre() + (dia - 1));
        }
    }

    /**
     * Muestra el estado de cada mascota
     */
    public static void verEstado(Mascota Uno, Mascota Dos, Mascota Tres) {
        Scanner sc = new Scanner(System.in);
        System.out.println("¿De qué mascota quieres ver el estado? \n1. Trompita \n2. Bola \n3.John\n4. Todos\n 5.Salir");
        int opcion = sc.nextInt(); //pedimos que nos de un numero segun el estado que quiera ver
        boolean repetir = true; //creamos un boolean para repetir el menú
        while (opcion != 5) { //mientras opcion no sea 5, debe seguir el bucle

            if (!repetir) { //cuando repetir=false debe mostrar de nuevo el menú
                System.out.println("¿De qué mascota quieres ver el estado? \n1. Trompita \n2. Bola \n3.John\n4. Todos\n 5.Salir");
                opcion = sc.nextInt();
                repetir = true;

            }
            switch (opcion) {
                case 1:
                    Uno.mostrarEstado(); //llama al método_ de la clase para la mascota uno
                    repetir = false;
                    break;
                case 2:
                    Dos.mostrarEstado();
                    repetir = false;
                    break;
                case 3:
                    Tres.mostrarEstado();
                    repetir = false;
                    break;
                case 4:
                    Uno.mostrarEstado(); //en este caso, llama a los 3 métodos
                    Dos.mostrarEstado();
                    Tres.mostrarEstado();
                    break;
                case 5:
                    System.out.println("Saliendo del comedor de mascotas. . ."); //muestra un mensaje de despedida
                    break;
                default:
                    System.out.println("Número no reconocido, vuelve a intentarlo más tarde"); //muestra mensaje de error
                    repetir = false;
                    break;
            }
        }
    }

        /**
         * Método_ para alimentar a las mascotas.
         */
        public static void Alimentar (Mascota Uno, Mascota Dos, Mascota Tres){
            Scanner sc = new Scanner(System.in);
            System.out.println("¿A qué mascota quieres alimentar? \n1. Trompita \n2. Bola \n3.John\n4. Salir");
            int opcion = sc.nextInt(); //pedimos que elija una opción
            boolean repetir = true;
            while (opcion != 4) { //bucle en el que sino se elige la opción de salida, se sigue en él
                if (!repetir) { //sirve para repetir el menú
                    System.out.println("¿A qué mascota quieres alimentar? \n1. Trompita \n2. Bola \n3.John\n4. Salir");
                    opcion = sc.nextInt();
                    repetir = true;

                }
                switch (opcion) { //según la opción que escoja, se alimenta a una mascota u otra
                    case 1:
                        Uno.alimentar();
                        repetir = false; //sirve para que se repita el menú
                        break;
                    case 2:
                        Dos.alimentar();
                        repetir = false;
                        break;
                    case 3:
                        Tres.alimentar();
                        repetir = false;
                        break;
                    case 4:
                        System.out.println("Saliendo del comedor de mascotas. . ."); //mensaje de despedida
                        break;
                    default:
                        System.out.println("Número no reconocido, vuelve a intentarlo más tarde"); //mensaje de error
                        repetir = false;
                        break;
                }
            }

        }

        /**
         * Método_ para jugar con las mascotas
         */
        public static void Jugar (Mascota Uno, Mascota Dos, Mascota Tres){
            Scanner sc = new Scanner(System.in);
            System.out.println("Entrando al patio de juegos. . .");
            System.out.println();
            System.out.println("¿Con qué mascota quieres jugar? \n1.Trompita\n2.Bola\n3.John\n4.Salir");
            int opcion = sc.nextInt(); //pedimos que nos de un numero segun a cuál elija
            boolean repetir = true; //sirve para repetir el menú
            while (opcion != 4) {
                if (!repetir) {
                    System.out.println("¿Con qué mascota quieres jugar? \n1.Trompita\n2.Bola\n3.John\n4.Salir");
                    opcion = sc.nextInt();
                    repetir = true;

                }
                switch (opcion) {
                    case 1:
                        Uno.jugar();
                        repetir = false;
                        break;
                    case 2:
                        Dos.jugar();
                        repetir = false;
                        break;
                    case 3:
                        Tres.jugar();
                        repetir = false;
                        break;
                    case 4:
                        System.out.println("Saliendo del patio de juegos. . .");
                    default:
                        System.out.println("Mascota no identificada, por favor, vuelve a intentarlo");
                }
            }
        }
        /**
         * Método_ para mandar a las mascotas a dormir.
         *
         */
        public static void Dormir (Mascota Uno, Mascota Dos, Mascota Tres){
            Scanner sc = new Scanner(System.in);
            System.out.println("Entrando en la sala de descanso. . .");
            System.out.println("¿A qué mascota quieres mandar a dormir? \n1. Trompita \n2. Bola \n3.John\n4. Salir");
            int opcion = sc.nextInt(); //pedimos que nos de un numero segun a cuál elija
            boolean repetir = true;
            while (opcion != 4) {

                if (!repetir) {
                    System.out.println("¿A qué mascota quieres mandar a dormir? \n1. Trompita \n2. Bola \n3.John\n4. Salir");
                    opcion = sc.nextInt();
                    repetir = true;
                }
                switch (opcion) {
                    case 1:
                        Uno.dormir();
                        repetir = false;
                        break;
                    case 2:
                        Dos.dormir();
                        repetir = false;
                        break;
                    case 3:
                        Tres.dormir();
                        repetir = false;
                        break;
                    case 4:
                        System.out.println("Saliendo de la sala de descanso. . .");
                        break;
                    default:
                        System.out.println("Mascota no reconocida, por favor, vuelve a intentarlo");
                        repetir = false;
                        break;

                }

            }
        }

        public static void Cumpleaños (Mascota Uno, Mascota Dos, Mascota Tres){
            Scanner sc = new Scanner(System.in);
            System.out.println("¿Qué mascota quieres que cumpla años? \n1. Trompita \n2. Bola \n3.John\n4. Salir");
            int opcion = sc.nextInt(); //pedimos que nos de un numero segun a cuál elija
            boolean repetir = true;
            while (opcion != 4) {
                if (!repetir) {
                    System.out.println("¿Qué mascota quieres que cumpla años? \n1. Trompita \n2. Bola \n3.John\n4. Salir");
                    opcion = sc.nextInt();
                    repetir = true;
                }
                switch (opcion) {
                    case 1:
                        Uno.cumplirAños();
                        repetir = false;
                        break;
                    case 2:
                        Dos.cumplirAños();
                        repetir = false;
                        break;
                    case 3:
                        Tres.cumplirAños();
                        repetir = false;
                        break;
                    case 4:
                        System.out.println("Terminando el día. . .");
                        break;
                    default:
                        System.out.println("Mascota no reconocida, por favor, vuelve a intentarlo");
                        repetir = false;
                        break;


                }
            }

        }
        /**
         *Muestra si la mascota está triste, enferma o hambrienta, sirve para advertir al usuario
         * En este método_ NO puede entrar el usuario por voluntad, es automático
         * @param arrayMascotas Array en el que se encuentran todas las mascotas
         */

        public static void ComprobarEstado (Mascota[]arrayMascotas){
            for (Mascota m : arrayMascotas) { //para comprobar los estados de las mascotas, he usado un array que recorra cada una
                if (m.getHambre() >= 7 && m.getFelicidad() <= 3) { //si una mascota tiene la felicidad baja y el hambre alta, se llama al método_ estáEnfermo()
                    m.estáEnfermo();
                } else if (m.getHambre() >= 7) { //si solo tiene hambre alta llama a estáHambriento()
                    m.estáHambriento();
                } else if (m.getFelicidad() <= 3) { //si tiene la felicidad baja, llama a estáTriste
                    m.estáTriste();
                } else if (m.getHambre() == 10) { //si tiene el hambre en el máximo, muestra un mensaje de advertencia
                    System.out.println("¡Cuidado! " + m.getNombre() + " está desnutrido, por favor, aliméntalo lo antes posible.");
                }
            }

        }

        /**
         * Muestra el estado del refugio
         */
        public static void EstadoRefugio (Mascota Uno, Mascota Dos, Mascota Tres, Mascota[]arrayMascota){
            int promedio_felicidad = (Uno.getFelicidad() + Dos.getFelicidad() + Tres.getFelicidad()) / 3; //suma de los tres valores de felicidad y dividido entre numero de mascotas
            int promedio_hambre = (Uno.getHambre() + Dos.getHambre() + Tres.getHambre()) / 3; //suma de los valores de hambre y dividido entre el número de mascotas
            System.out.println("La felicidad promedio de las mascotas es de: " + promedio_felicidad);
            System.out.println("El hambre promedio de las mascotas es de: " + promedio_hambre);
            System.out.println("----------------------------------------------------");
            ComprobarEstado(arrayMascota); //llamamos a la otra función para que muestre el estado de cada mascota
            System.out.println("----------------------------------------------------");
        }



}