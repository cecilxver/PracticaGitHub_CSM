import java.util.Set;

public class Mascota {//creamos la clase con los atributos privados
    private String nombre="John"; //en estas variables se encuentran los valores de los objetos
    private String tipo="Pork";
    private int edad=0;
    private int hambre=0;
    private int felicidad=0;
    Mascota(){}
Mascota(String nombre, String tipo, int edad, int hambre, int felicidad){ //creamos el constructor
    this.nombre=nombre; //guardamos en la variable global, el valor que nos de el usuario para construir el objeto
    this.tipo=tipo;
    this.edad=edad;
    this.felicidad=felicidad;
    this.hambre=hambre;

}

    /**
     * Sirve para que se pueda controlar que la felicidad no pase de unos rangos
     * y poder modificarla.
     */
    public void setFelicidad(int felicidad) {
        this.felicidad=felicidad;
        if (this.felicidad<=0) { //si la felicidad es menor que 0 debe de valer 0
            this.felicidad=0;
        } else if (this.felicidad>=10) { //si la felicidad es mayor que 10, debe valer 10
            this.felicidad=10;
        }
    }
    //Todos los atributos son privados, por lo que para acceder a ellos desde el main, debemos usar get.
    public String getNombre() {
        return nombre;
    }

    public int getHambre(){
        return hambre;
    }
    public int getFelicidad(){
        return felicidad;
    }

    /**
     * Sirve para que se pueda controlar que el hambre no pase de unos rangos
     * y poder modificarla.
     */
    public void setHambre(int hambre) {
        this.hambre=hambre; //guardamos en la variable global el valor de la variable local
        if (this.hambre==0) { //si vale 0, debe aumentar la felicidad
            felicidad++;
        } else if ((this.hambre < 0)) {//en el caso de que valga menos de 0, debe valer 0
            this.hambre=0;
        } else if (this.hambre>10) { //si vale más de 10, debe valer 10
            this.hambre=10;
        }

    }

    /**
     * Muestra los datos de las mascotas
     */
    public void mostrarEstado(){
    System.out.println("----------------------------------------");
    System.out.println("Nombre: "+nombre+"\nTipo: "+tipo+"\n" + //se hace un print de los datos
            "Edad: "+edad+" años \nHambre: "+hambre+"\n" +
            "Felicidad: "+felicidad);
    System.out.println("----------------------------------------");


}

    /**
     * Alimenta a la mascota.
     */
    public void alimentar(){
    System.out.println("-------------------------------------");
    System.out.println("Alimentando a "+nombre);
        setHambre(getHambre()-3); //no se puede cambiar la variable en si, por lo que llamamos al método_ para cambiar la variable y que esté entre los rangos
        // y para que agarre el valor de la variable

    System.out.println("Hambre de "+nombre+" es: "+hambre); //lo mostramos
    System.out.println("-------------------------------------");


}

    /**
     * Duerme a la mascota.
     */
    public void dormir() {
        System.out.println("¡Has mandado a " + nombre + " a dormir!");
        setHambre(getHambre() + 1); //hacemos que hambre incremente
        setFelicidad(getFelicidad() + 1);//felicidad incrementa
    }

    /**
     * Juega con la mascota.
     */
    public void jugar(){
    System.out.println("---------------------------");
    System.out.println("Jugando con: "+nombre);
    setFelicidad(getFelicidad()+2); //hacemos que la felicidad aumente 2
    setHambre(getHambre()+1); //hacemos que el hambre aumente 2
    System.out.println("La felicidad de "+ nombre+" es: "+felicidad);
    System.out.println("---------------------------");


}

    /**
     * Hace que la mascota cumpla años.
     */
    public void cumplirAños(){
        setFelicidad(getFelicidad()-2);//en este caso, use lo de bajar la felicidad aunque no estuviese puesto porque sino no bajaba nunca
        edad++;//aumentamos la edad
    System.out.println("------------------------------");
    System.out.println("¡Felicidades! "+nombre+" ha cumplido "+edad+"  años");
}

    /**
     * Muestra si la mascota tiene pocos niveles de felicidad.
     */
    public void estáTriste(){
        if(getFelicidad()<3){ //si su felicidad es menor que 3, muestra esto
            System.out.println(nombre+" está triste! Juega y alimenta a tu mascota para que esté feliz");
        }

}

    /**
     * Muestra si la mascota está hambrienta.
     */
    public void estáHambriento(){
        if (getHambre()>7){ //si su hambre es mayor a 7, muestra esto
            System.out.println(nombre+" está hambrienta! Alimenta a tu mascota antes de que sea tarde");
        }
}

    /**
     * Muestra si la mascota está enferma.
     */
    public void estáEnfermo(){
        if (getHambre()>7&&getFelicidad()<3){ //si el hambre está alto y la felicidad baja, muestra un mensaje de aviso
            System.out.println(nombre+" está enfermo! Alimentalo y juega con ella antes de que sea tarde. . .");
        }
    }




}
